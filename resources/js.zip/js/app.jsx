import './bootstrap';
import '../css/home.css'
import '../css/master.css'
import '../css/f_footer.css'
import { createInertiaApp } from '@inertiajs/react';
import { createRoot } from 'react-dom/client';

// Create the Inertia app
createInertiaApp({
    resolve: (name) => {
        const pages = import.meta.glob('./Pages/**/*.jsx', { eager: true });
        return pages[`./Pages/${name}.jsx`];
    },
    setup({ el, App, props }) {
        createRoot(el).render(<App {...props} />);
    },
});
